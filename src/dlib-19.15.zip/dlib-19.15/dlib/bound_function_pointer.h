// Copyright (C) 2008  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_BOUND_FUNCTION_POINTEr_
#define DLIB_BOUND_FUNCTION_POINTEr_

#include "bound_function_pointer/bound_function_pointer_kernel_1.h"

#endif // DLIB_BOUND_FUNCTION_POINTEr_ 


